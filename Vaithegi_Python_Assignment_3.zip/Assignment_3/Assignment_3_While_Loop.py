import random

secret_number = random.randint(1, 10)
attempts = 3

print("Welcome to the Number Guessing Game!")
print("Guess a number between 1 and 10.")
print("You have", attempts, "attempts to guess the number.")

while attempts > 0:
    guess = input("Enter your guess: ")

    if not guess.isdigit():
        print("Invalid input! Please enter a number.")
        continue

    guess = int(guess)

    if guess < 1 or guess > 10:
        print("Please enter a number between 1 and 10.")
        continue

    attempts -= 1

    if guess == secret_number:
        print("Congratulations! You guessed the correct number.")
        break
    elif guess < secret_number:
        print("Your guess is too low. Try again!")
    else:
        print("Your guess is too high. Try again!")

    if attempts > 0:
        print("Attempts remaining:", attempts)
else:
    print("Game over! The correct number was", secret_number)