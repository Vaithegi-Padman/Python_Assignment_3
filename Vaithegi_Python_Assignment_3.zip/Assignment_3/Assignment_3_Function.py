def calculate_bmi(weight, height):
    return weight / (height ** 2)

# Prompt the user for input
weight = float(input("Enter your weight in kg: "))
height = float(input("Enter your height in meters: "))

# Calculate BMI
bmi = calculate_bmi(weight, height)

# Display result with 2 decimal places
print(f"Your BMI is: {bmi:.2f}")
